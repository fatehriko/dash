package players;

import cards.Card;
import game.GameSession;
import game.RuleEngine;

import java.util.ArrayList;
import java.util.List;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Abstract class representing a player in the game.
 * This class provides common functionality for all types of players.
 */
public abstract class Player {
    private String name;
    private List<Card> hand;
    private int score;
    private int wins;
    private int losses;
    private int gamesPlayed;
    private int totalScore;

    /**
     * Constructs a new player with the given name.
     * @param name The name of the player.
     */
    public Player(String name) {
        this.name = name;
        this.hand = new ArrayList<>();
        this.score = 0;
    }
    
    
    public void recordWin() {
        this.wins++;
        this.gamesPlayed++;
    }

    public void recordLoss() {
        this.losses++;
        this.gamesPlayed++;
    }

    public int getWins() {
        return wins;
    }

    public int getLosses() {
        return losses;
    }

    public int getGamesPlayed() {
        return gamesPlayed;
    }

    public double getAverageScore() {
        return gamesPlayed > 0 ? (double) totalScore / gamesPlayed : 0.0;
    }
    
    public double getWinLossRatio() {
        return losses > 0 ? (double) wins / losses : wins;
    }
    
    /**
     * Updates the player's score.
     * @param scoreChange The amount to add to the player's score (can be negative if subtracting).
     */
    public void updateScore(int scoreChange) {
        this.score += scoreChange;
        System.out.println(name + " score updated to " + this.score);
    }
    
    /**
     * Returns the current score of the player.
     * @return The current score.
     */
    public int getScore() {
        return score;
    }

    /**
     * Adds a card to the player's hand.
     * @param card The card to add to the hand.
     */
    public void addCardToHand(Card card) {
        hand.add(card);
    }

    /**
     * Removes a card from the player's hand.
     * @param card The card to remove from the hand.
     * @return true if the card was successfully removed, false otherwise.
     */
    public boolean removeCardFromHand(Card card) {
        return hand.remove(card);
    }

    /**
     * Gets the player's hand.
     * @return A list of cards in the player's hand.
     */
    public List<Card> getHand() {
        return hand;
    }

    /**
     * Returns the number of cards in the player's hand.
     * @return The size of the hand.
     */
    public int getHandSize() {
        return hand.size();
    }

    /**
     * Gets the player's name.
     * @return The name of the player.
     */
    public String getName() {
        return name;
    }

    /**
     * Abstract method for the player's turn to play a card.
     * Specific implementations will be in the subclasses for human and AI players.
     * @param gameSession The current game session in which the player is playing.
     */
    public abstract void playTurn(GameSession gameSession, RuleEngine ruleEngine);

    @Override
    public String toString() {
        return "Player{" +
               "name='" + name + '\'' +
               ", handSize=" + hand.size() +
               '}';
    }
}

