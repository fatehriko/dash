package players;

import game.GameSession;
import game.RuleEngine;
import cards.Card;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Represents a bot in the game.
 */
public class ComputerPlayer extends Player {
    private Random random;

    /**
     * Constructs a new ComputerPlayer with the given name.
     * @param name The name of the computer player.
     */
    public ComputerPlayer(String name) {
        super(name);
        this.random = new Random();
    }

    /**
     * Plays a turn for the computer player using simple AI logic.
     * @param gameSession The current game session in which the player is playing.
     * @param ruleEngine The rule engine used to validate moves and apply effects.
     */
    @Override
    public void playTurn(GameSession gameSession, RuleEngine ruleEngine) {
        List<Card> validCards = new ArrayList<>();
        for (Card card : getHand()) {
            if (ruleEngine.isValidMove(card, gameSession.getTopCard(), gameSession.getCurrentColour())) {
                validCards.add(card);
            }
        }

        if (!validCards.isEmpty()) {
            Card cardToPlay = validCards.get(random.nextInt(validCards.size()));
            System.out.println(getName() + " plays " + cardToPlay);
            removeCardFromHand(cardToPlay);
            gameSession.addCardToDiscardPile(cardToPlay);
            ruleEngine.applyCardEffect(cardToPlay, gameSession);
        } else {
            drawAndPlay(gameSession, ruleEngine);
        }
    }

    /**
     * Draws cards until a valid card can be played or the draw pile is exhausted.
     * @param gameSession The current game session.
     * @param ruleEngine The rule engine to validate moves.
     */
    private void drawAndPlay(GameSession gameSession, RuleEngine ruleEngine) {
        boolean played = false;
        while (!played && !gameSession.isDrawPileEmpty()) {
            Card drawnCard = gameSession.drawCard();
            System.out.println(getName() + " has no valid card to play, draws a card: " + drawnCard);
            addCardToHand(drawnCard);
            if (ruleEngine.isValidMove(drawnCard, gameSession.getTopCard(), gameSession.getCurrentColour())) {
                System.out.println(getName() + " plays " + drawnCard);
                removeCardFromHand(drawnCard);
                gameSession.addCardToDiscardPile(drawnCard);
                ruleEngine.applyCardEffect(drawnCard, gameSession);
                played = true;
            }
        }
        if (!played) {
            System.out.println(getName() + " could not play any card this turn.");
        }
    }
}

