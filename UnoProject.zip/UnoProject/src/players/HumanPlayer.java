package players;

import game.GameSession;
import game.RuleEngine;
import cards.Card;
import cards.ActionCard;
import cards.WildCard;

import java.util.Scanner;

/**
 * Represents a human-controlled player in the game.
 */
public class HumanPlayer extends Player {
    private Scanner scanner;

    public HumanPlayer() {
        super("Human Player");
        this.scanner = new Scanner(System.in);
    }

    private void promptForUno() {
        System.out.println("Do you want to declare Uno? (yes/no)");
        String response = scanner.nextLine().trim().toLowerCase();
        if ("yes".equals(response)) {
            System.out.println(getName() + " declared Uno!");
        }
    }

    private Card.Colour promptForColor() {
        System.out.println("Choose a color (RED, YELLOW, BLUE, GREEN):");
        String colorInput = scanner.nextLine().trim().toUpperCase();
        try {
            return Card.Colour.valueOf(colorInput);
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid color input. Defaulting to RED.");
            return Card.Colour.RED;
        }
    }

    @Override
    public void playTurn(GameSession gameSession, RuleEngine ruleEngine) {
        boolean played = false;
        while (!played) {
            System.out.println("Your turn, " + getName() + ". Your hand:");
            listHand();
            System.out.println("Select a card to play or type 'draw' to draw a card:");

            String input = scanner.nextLine().trim();
            if ("draw".equalsIgnoreCase(input)) {
                Card drawnCard = gameSession.drawCard();
                addCardToHand(drawnCard);
                System.out.println("You drew: " + drawnCard);
                break;  // Exit the play loop after drawing
            }

            try {
                int choice = Integer.parseInt(input) - 1;
                Card chosenCard = getHand().get(choice);
                if (ruleEngine.isValidMove(chosenCard, gameSession.getTopCard(), gameSession.getCurrentColour())) {
                    removeCardFromHand(chosenCard);
                    gameSession.addCardToDiscardPile(chosenCard);
                    ruleEngine.applyCardEffect(chosenCard, gameSession);
                    if (chosenCard instanceof WildCard) {
                        gameSession.setCurrentColour(promptForColor());
                    }
                    played = true;
                    if (getHandSize() == 1) {
                        promptForUno();
                    }
                } else {
                    System.out.println("Invalid move. Please try again.");
                }
            } catch (Exception e) {
                System.out.println("Invalid input. Please enter a valid card number or 'draw'.");
            }
        }
    }

    private void listHand() {
        for (int i = 0; i < getHand().size(); i++) {
            System.out.println((i + 1) + ": " + getHand().get(i));
        }
    }


    public void close() {
        if (scanner != null) {
            scanner.close();
        }
    }
}
