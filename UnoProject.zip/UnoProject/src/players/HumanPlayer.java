package players;

import game.GameSession;
import game.RuleEngine;
import cards.Card;

import java.util.Scanner;

/**
 * Represents a human-controlled player in the game.
 */
public class HumanPlayer extends Player {
    private Scanner scanner;        
    private boolean hasDeclaredUno;  

    /**
     * Constructs a new human player with a specified name.
     * @param name The name of the player.
     */
    public HumanPlayer(String name) {
        super(name);
        this.scanner = new Scanner(System.in);
        this.hasDeclaredUno = false;
    }
    
    /**
     * Marks that this player has declared "Uno".
     */
    public void declareUno() {
        hasDeclaredUno = true;
    }

    /**
     * Plays a turn for this player. This method prompts the player to choose a card
     * to play from their hand, validates the move, and applies the card's effects
     * to the game session.
     * @param gameSession The current game session where the game is being played.
     * @param ruleEngine The set of rules governing valid moves and card effects.
     */
    @Override
    public void playTurn(GameSession gameSession, RuleEngine ruleEngine) {
        System.out.println("Your turn, " + getName() + ". Your hand:");
        for (int i = 0; i < getHand().size(); i++) {
            System.out.println((i + 1) + ". " + getHand().get(i));
        }
        System.out.println("Choose a card to play (1-" + getHand().size() + "):");

        int choice = scanner.nextInt();
        while (choice < 1 || choice > getHand().size()) {
            System.out.println("Invalid choice, try again.");
            choice = scanner.nextInt();
        }

        Card chosenCard = getHand().get(choice - 1);
        if (ruleEngine.isValidMove(chosenCard, gameSession.getTopCard(), gameSession.getCurrentColour())) {
            removeCardFromHand(chosenCard);
            gameSession.addCardToDiscardPile(chosenCard);
            ruleEngine.applyCardEffect(chosenCard, gameSession);
        } else {
            System.out.println("You cannot play this card. Choose another.");
            playTurn(gameSession, ruleEngine);  // Recursively prompt to choose again if the choice was invalid
        }
        
        if (getHandSize() == 1 && !hasDeclaredUno) {
            System.out.println(getName() + " failed to declare Uno!");
            gameSession.issueUnoPenalty(this);
        }
        
        hasDeclaredUno = false;
    }

    /**
     * Closes the scanner object used for input.
     */
    public void close() {
        scanner.close();
    }
}
