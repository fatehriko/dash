package players;

import game.GameSession;
import game.RuleEngine;
import cards.Card;
import cards.ActionCard;
import cards.WildCard;

import java.util.Scanner;

/**
 * Represents a human-controlled player in the game.
 */
public class HumanPlayer extends Player {
    private Scanner scanner;

    public HumanPlayer(String name) {
        super(name);
        this.scanner = new Scanner(System.in);
    }

    @Override
    public void playTurn(GameSession gameSession, RuleEngine ruleEngine) {
        boolean turnEnded = false;
        while (!turnEnded) {
            System.out.println("Your turn, " + getName() + ". Your hand:");
            for (int i = 0; i < getHand().size(); i++) {
                System.out.println((i + 1) + ". " + getHand().get(i));
            }

            System.out.println("Choose a card to play, type 'draw' to draw a card, or type 'end' to end your turn:");
            String input = scanner.nextLine().trim();

            if ("draw".equalsIgnoreCase(input)) {
                Card drawnCard = gameSession.drawCard();
                addCardToHand(drawnCard);
                System.out.println("You drew: " + drawnCard);
            } else if ("end".equalsIgnoreCase(input)) {
                System.out.println("Ending your turn.");
                turnEnded = true;
            } else {
                try {
                    int choice = Integer.parseInt(input) - 1;
                    if (choice >= 0 && choice < getHand().size()) {
                        Card chosenCard = getHand().get(choice);
                        if (ruleEngine.isValidMove(chosenCard, gameSession.getTopCard(), gameSession.getCurrentColour())) {
                            if (removeCardFromHand(chosenCard)) {
                                gameSession.addCardToDiscardPile(chosenCard);
                                ruleEngine.applyCardEffect(chosenCard, gameSession);
                                if (chosenCard instanceof WildCard) {
                                    System.out.println("You played a Wild card. Choose a color (RED, YELLOW, GREEN, BLUE):");
                                    String colorChoice = scanner.nextLine().trim().toUpperCase();
                                    switch (colorChoice) {
                                        case "RED":
                                        case "YELLOW":
                                        case "GREEN":
                                        case "BLUE":
                                            gameSession.setCurrentColour(Card.Colour.valueOf(colorChoice));
                                            break;
                                        default:
                                            System.out.println("Invalid color. Defaulting to RED.");
                                            gameSession.setCurrentColour(Card.Colour.RED);
                                    }
                                }
                                turnEnded = true;
                            }
                        } else {
                            System.out.println("You cannot play this card. Choose another or draw.");
                        }
                    } else {
                        System.out.println("Invalid choice, try again.");
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input, please enter a number, 'draw', or 'end'.");
                }
            }
        }
    }




    private void drawAndDecide(GameSession gameSession, RuleEngine ruleEngine) {
        Card drawnCard = gameSession.drawCard();
        addCardToHand(drawnCard);
        System.out.println("Drew: " + drawnCard);

        if (ruleEngine.isValidMove(drawnCard, gameSession.getTopCard(), gameSession.getCurrentColour())) {
            System.out.println("You drew a playable card. Do you want to play this card? (yes/no)");
            String response = scanner.nextLine().trim();
            if ("yes".equalsIgnoreCase(response)) {
                playCard(drawnCard, gameSession, ruleEngine);
            }
        }
    }

    private void playCard(Card card, GameSession gameSession, RuleEngine ruleEngine) {
        removeCardFromHand(card);
        gameSession.addCardToDiscardPile(card);
        ruleEngine.applyCardEffect(card, gameSession);
        System.out.println(getName() + " plays " + card);
    }

    private boolean hasPlayableCard(GameSession gameSession, RuleEngine ruleEngine) {
        return getHand().stream().anyMatch(card -> ruleEngine.isValidMove(card, gameSession.getTopCard(), gameSession.getCurrentColour()));
    }

    public void close() {
        scanner.close();
    }
}

