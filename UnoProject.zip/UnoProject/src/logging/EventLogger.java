package logging;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * EventLogger class for logging events and actions in the Uno game.
 */
public class EventLogger {
    private static final String LOG_FILE = "events_log.txt";  // File to store the logs
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  // For timestamping logs

    /**
     * Writes a log message to the log file with a timestamp.
     * @param message The message to log.
     */
    public static void log(String message) {
        String timestamp = dateFormat.format(new Date());  // Get current time and date
        String logMessage = timestamp + " - " + message;  // Format the log message with timestamp

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(LOG_FILE, true))) {
            bw.write(logMessage);
            bw.newLine();  // Ensure each log entry is on a new line
        } catch (IOException e) {
            System.err.println("Error writing to log file: " + e.getMessage());
        }
    }
}
