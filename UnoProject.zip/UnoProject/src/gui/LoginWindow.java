package gui;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;

/**
 * LoginWindow class provides a GUI for user login or registration.
 */
public class LoginWindow extends JFrame {

    private final JPanel mainPanel;

    private JTextField usernameTextField;
    private JPasswordField passwordField;

    public LoginWindow() {
        setTitle("Login");
        setSize(360, 600);  // Adjust the size for a different aspect ratio
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);  // Center on screen
        mainPanel = new JPanel();
        mainPanel.setLayout(null);
        getContentPane().add(mainPanel);
        initComponents();
        setVisible(true);
    }

    private void initComponents() {
        addBackground();
        addUsernameField();
        addPasswordField();
        addLoginButton();
    }

    private void addBackground() {
        try {
            ImageIcon icon = new ImageIcon("src/gui/images/uno-logo.png");
            Image image = icon.getImage(); // Transform it 
            Image newimg = image.getScaledInstance(245, 120,  java.awt.Image.SCALE_SMOOTH); // Scale it the smooth way  
            icon = new ImageIcon(newimg);  // Transform it back
            JLabel background = new JLabel(icon);
            background.setBounds(60, 20, 240, 120); // Adjust the position and size
            background.setOpaque(true);
            mainPanel.add(background);
        } catch (Exception e) {
            System.err.println("Error loading or scaling the background image: " + e.getMessage());
        }
    }


    private void addUsernameField() {
        usernameTextField = new JTextField();
        usernameTextField.setBounds(30, 180, 300, 40);  // Adjust position and size
        usernameTextField.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
        usernameTextField.setHorizontalAlignment(JTextField.CENTER);
        mainPanel.add(usernameTextField);
    }

    private void addPasswordField() {
        passwordField = new JPasswordField();
        passwordField.setBounds(30, 240, 300, 40);  // Adjust position and size
        passwordField.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
        passwordField.setHorizontalAlignment(JTextField.CENTER);
        mainPanel.add(passwordField);
    }

    private void addLoginButton() {
        JButton loginButton = new JButton("Login");
        loginButton.setBounds(100, 300, 160, 40);  // Adjust position and size
        loginButton.addActionListener(e -> performLogin());
        mainPanel.add(loginButton);
    }

    private void performLogin() {
        String username = usernameTextField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter both username and password.", "Warning", JOptionPane.WARNING_MESSAGE);
        } else {
            System.out.println("Login attempt with Username: " + username + " and Password: " + password);
            // Further login logic here...
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(LoginWindow::new);
    }
}

