package gui;

import javax.swing.*;
import java.awt.*;

/**
 * UserStatsWindow class creates a window to display statistics for a specific player in the Uno game.
 */
public class UserStatsWindow extends JFrame {
    private JLabel gamesPlayedLabel;
    private JLabel winsLabel;
    private JLabel lossesLabel;
    private JLabel totalScoreLabel;

    public UserStatsWindow(String playerName, int gamesPlayed, int wins, int losses, int totalScore) {
        setTitle("Player Statistics - " + playerName);
        setSize(350, 200);  // Set the size of the frame
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);  // Center the window
        setLayout(new GridLayout(4, 2, 10, 10));  // Layout with rows and columns

        // Initialize labels
        gamesPlayedLabel = new JLabel("Games Played: " + gamesPlayed);
        winsLabel = new JLabel("Wins: " + wins);
        lossesLabel = new JLabel("Losses: " + losses);
        totalScoreLabel = new JLabel("Total Score: " + totalScore);

        // Adding labels to frame
        add(new JLabel("Games Played:"));
        add(gamesPlayedLabel);
        add(new JLabel("Wins:"));
        add(winsLabel);
        add(new JLabel("Losses:"));
        add(lossesLabel);
        add(new JLabel("Total Score:"));
        add(totalScoreLabel);

        setVisible(true);  // Make the frame visible
    }

    public static void main(String[] args) {
        // Example usage with sample data
        SwingUtilities.invokeLater(() -> new UserStatsWindow("Alice", 25, 15, 10, 350));
    }
}

