package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * MainMenu class creates the main menu for the Uno game.
 */
public class MainMenu extends JFrame {
    private JButton newGameButton;
    private JButton loadGameButton;
    private JButton leaderboardButton;
    private JButton statsButton;
    private JButton logoutButton;

    public MainMenu() {
        setTitle("Uno Game - Main Menu");
        setSize(300, 200);  // Set the size of the frame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);  // Center the window
        setLayout(new GridLayout(5, 1, 10, 10));  // Layout with vertical spacing

        // Initialize buttons
        newGameButton = new JButton("Start New Game");
        loadGameButton = new JButton("Load Game");
        leaderboardButton = new JButton("View Leaderboard");
        statsButton = new JButton("User Statistics");
        logoutButton = new JButton("Logout");

        // Add action listeners to buttons
        newGameButton.addActionListener(e -> startNewGame());
        loadGameButton.addActionListener(e -> loadGame());
        leaderboardButton.addActionListener(e -> viewLeaderboard());
        statsButton.addActionListener(e -> viewStats());
        logoutButton.addActionListener(e -> logout());

        // Add buttons to the frame
        add(newGameButton);
        add(loadGameButton);
        add(leaderboardButton);
        add(statsButton);
        add(logoutButton);

        setVisible(true);  // Make the frame visible
    }

    private void startNewGame() {
        System.out.println("Starting a new game...");
        // Code to start a new game
    }

    private void loadGame() {
        System.out.println("Loading a game...");
        // Code to load a saved game
    }

    private void viewLeaderboard() {
        System.out.println("Viewing leaderboard...");
        // Code to display leaderboard
    }

    private void viewStats() {
        System.out.println("Viewing user statistics...");
        // Code to display user statistics
    }

    private void logout() {
        System.out.println("Logging out...");
        dispose();  // Close the window
        // Code to handle logout
    }

    public static void main(String[] args) {
        // Ensure the GUI is created on the Event Dispatch Thread
        SwingUtilities.invokeLater(MainMenu::new);
    }
}
