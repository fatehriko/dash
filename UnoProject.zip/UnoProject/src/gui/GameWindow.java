package gui;

import cards.*;
import cards.Card.Colour;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class GameWindow extends JFrame {
    private List<JButton> cardButtons;
    private JPanel cardsPanel;

    public GameWindow() {
        setTitle("Uno Game");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        initializeComponents();
        setVisible(true);
    }
    
    

    private void initializeComponents() {
        cardsPanel = new JPanel(new FlowLayout());
        cardButtons = new ArrayList<>();
        List<NumberCard> initialHand = new ArrayList<>();
        initialHand.add(new NumberCard(Colour.RED, 5));
        initialHand.add(new NumberCard(Colour.BLUE, 2));

        updatePlayerHand(initialHand);
    }

    private void updatePlayerHand(List<NumberCard> hand) {
        cardsPanel.removeAll();
        cardButtons.clear();  // Clear the old buttons list
        for (NumberCard card : hand) {
            JButton button = new JButton(card.toString());
            cardButtons.add(button);
            cardsPanel.add(button);
        }
        cardsPanel.revalidate();
        cardsPanel.repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(GameWindow::new);
    }
}


