package gui;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.Vector;

/**
 * LeaderBoardWindow class creates the leaderboard window for the Uno game.
 */
public class LeaderBoardWindow extends JFrame {
    private JTable leaderboardTable;

    public LeaderBoardWindow(List<PlayerStats> playerStats) {
        setTitle("Uno Game - Leaderboard");
        setSize(400, 300);  // Set the size of the frame
        setLocationRelativeTo(null);  // Center the window
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Create column names for the table
        Vector<String> columnNames = new Vector<>();
        columnNames.add("Player Name");
        columnNames.add("Games Played");
        columnNames.add("Wins");
        columnNames.add("Losses");
        columnNames.add("Total Score");

        // Create data for the table
        Vector<Vector<Object>> data = new Vector<>();
        for (PlayerStats stats : playerStats) {
            Vector<Object> row = new Vector<>();
            row.add(stats.getName());
            row.add(stats.getGamesPlayed());
            row.add(stats.getWins());
            row.add(stats.getLosses());
            row.add(stats.getTotalScore());
            data.add(row);
        }

        // Initialize the table with data and column names
        leaderboardTable = new JTable(data, columnNames);
        leaderboardTable.setFillsViewportHeight(true);

        // Add a JScrollPane to the table
        JScrollPane scrollPane = new JScrollPane(leaderboardTable);
        add(scrollPane, BorderLayout.CENTER);

        setVisible(true);  // Make the frame visible
    }

    // Example usage
    public static void main(String[] args) {
        // Mock data for demonstration
        List<PlayerStats> playerStats = List.of(
            new PlayerStats("Alice", 20, 15, 5, 300),
            new PlayerStats("Bob", 20, 10, 10, 250),
            new PlayerStats("Charlie", 20, 5, 15, 200)
        );
        SwingUtilities.invokeLater(() -> new LeaderBoardWindow(playerStats));
    }

    /**
     * PlayerStats class to store statistics for each player.
     */
    public static class PlayerStats {
        private String name;
        private int gamesPlayed;
        private int wins;
        private int losses;
        private int totalScore;

        public PlayerStats(String name, int gamesPlayed, int wins, int losses, int totalScore) {
            this.name = name;
            this.gamesPlayed = gamesPlayed;
            this.wins = wins;
            this.losses = losses;
            this.totalScore = totalScore;
        }

        public String getName() {
            return name;
        }

        public int getGamesPlayed() {
            return gamesPlayed;
        }

        public int getWins() {
            return wins;
        }

        public int getLosses() {
            return losses;
        }

        public int getTotalScore() {
            return totalScore;
        }
    }
}
