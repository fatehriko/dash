	/************** Pledge of Honor ******************************************
	I hereby certify that I have completed this programming project on my own
	without any help from anyone else. The effort in the project thus belongs
	completely to me. I did not search for a solution, or I did not consult any
	program written by others or did not copy any program from other sources. I
	read and followed the guidelines provided in the project description.
	READ AND SIGN BY WRITING YOUR NAME SURNAME AND STUDENT ID
	SIGNATURE: <Riad Shahbazov, 0085553>
	*************************************************************************/

package main;
import gui.LoginWindow;  // Assume LoginWindow is the starting GUI class
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

	/**
	 * Main class to launch the Uno game application.
	 */
	public class Main {

	    /**
	     * Main method to start the application.
	     * @param args command line arguments
	     */
	    public static void main(String[] args) {
	        System.out.println("Starting Uno Game...");
	        SwingUtilities.invokeLater(() -> {
	            try {
	                // Set the look and feel to the system's default to make it more integrated.
	                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
	            } catch (Exception e) {
	                System.err.println("Failed to set the look and feel.");
	            }
	            
	            new LoginWindow();  // Create and display the login window
	        });
	    }
	}
