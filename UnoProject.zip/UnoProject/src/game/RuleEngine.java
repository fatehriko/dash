package game;

import cards.Card;
import cards.Card.Colour;
import cards.ActionCard;
import cards.NumberCard;
import cards.SpecialWildCard;
import cards.WildCard;

/**
 * The RuleEngine class handles the application of game rules,
 * including validating moves and applying card effects.
 */
public class RuleEngine {

    /**
     * Validates if a player's move is valid according to the rules.
     * @param card The card the player wishes to play.
     * @param currentTopCard The current top card on the discard pile.
     * @return true if the move is valid; false otherwise.
     */
	public boolean isValidMove(Card card, Card currentTopCard, Colour currentGameColor) {
		if (currentTopCard == null) {
            return true;
        }
		
	    if (card instanceof WildCard) {
	        return true;
	    }

	    if (card.getColor() == currentGameColor) {
	        return true;
	    }

	    if (card instanceof NumberCard && currentTopCard instanceof NumberCard) {
	        NumberCard playerCard = (NumberCard) card;
	        NumberCard topCard = (NumberCard) currentTopCard;
	        if (playerCard.getNumber() == topCard.getNumber()) {
	            return true;
	        }
	    }

	    return false;
	}
    /**
     * Applies the effects of a card when it is played.
     * @param card The card being played.
     * @param gameSession The current session of the game, where the game state is managed.
     */
    public void applyCardEffect(Card card, GameSession gameSession) {
        if (card instanceof NumberCard) {
        } 
        
        else if (card instanceof ActionCard) {
            applyActionCardEffect((ActionCard) card, gameSession);
        } 
        
        else if (card instanceof WildCard) {
            applyWildCardEffect((WildCard) card, gameSession);
        }
    }

    /**
     * Handles the effects specific to action cards.
     * @param card The action card being played.
     * @param gameSession The game session in which the action is to be applied.
     */
    private void applyActionCardEffect(ActionCard card, GameSession gameSession) {
        switch (card.getActionType()) {
            case SKIP:
                gameSession.advancePlayTurn();
                gameSession.advancePlayTurn();
                break;
            case REVERSE:
                gameSession.changePlayDirection();
                break;
            case DRAW_TWO:
                gameSession.advancePlayTurn();
                gameSession.drawCards(2);
                gameSession.advancePlayTurn();
                break;
        }
    }

    /**
     * Applies the effects of a wild card when it is played.
     * @param card The wild card being played.
     * @param gameSession The current session of the game, where the game state is managed.
     */
    private void applyWildCardEffect(WildCard card, GameSession gameSession) {
    	gameSession.setRandomColour(); 
        if (card instanceof SpecialWildCard) {
            handleSpecialWildCard(gameSession);
        } 
    }

    /**
     * Handles the specific effect of a Wild Draw Four card.
     * @param gameSession The game session where the card's effect is applied.
     */
    private void handleSpecialWildCard(GameSession gameSession) {
        gameSession.advancePlayTurn(); 
        gameSession.drawCards(4);       
        gameSession.advancePlayTurn(); 
    }
}
