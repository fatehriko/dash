package game;

import cards.Card;
import cards.Card.Colour;
import players.Player;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * GameSession class maintains the state and progression of a single game session.
 */
public class GameSession {
    public enum Direction {
        CLOCKWISE, COUNTERCLOCKWISE
    }

    private List<Player> players;
    private List<Card> drawPile;
    private List<Card> discardPile;
    private int currentPlayerIndex;
    private Direction gameDirection;
    private Colour currentColour;
    private boolean unoDeclared = false;

    /**
     * Gets the current colour in play.
     * @return The current colour being used in the game.
     */
    public Colour getCurrentColour() {
        return currentColour;
    }

    /**
     * Sets the current colour in play.
     * @param currentColour The new colour to set as the current game colour.
     */
    public void setCurrentColour(Colour currentColour) {
        this.currentColour = currentColour;
    }

    /**
     * Gets the current direction of the game play.
     * @return The current direction of play, either CLOCKWISE or COUNTERCLOCKWISE.
     */
    public Direction getGameDirection() {
        return gameDirection;
    }

    /**
     * Gets the list of players participating in the game.
     * @return A list of players currently playing the game.
     */
    public List<Player> getPlayers() {
        return players;
    }

    /**
     * Sets the list of players in the game.
     * @param players The list of players to set for the game.
     */
    public void setPlayers(List<Player> players) {
        this.players = players;
    }

    /**
     * Gets the current draw pile of cards.
     * @return The list of cards currently in the draw pile.
     */
    public List<Card> getDrawPile() {
        return drawPile;
    }

    /**
     * Sets the draw pile of the game.
     * @param drawPile The list of cards to be set as the new draw pile.
     */
    public void setDrawPile(List<Card> drawPile) {
        this.drawPile = drawPile;
    }

    /**
     * Gets the discard pile of cards.
     * @return The list of cards currently in the discard pile.
     */
    public List<Card> getDiscardPile() {
        return discardPile;
    }

    /**
     * Sets the discard pile of the game.
     * @param discardPile The list of cards to be set as the new discard pile.
     */
    public void setDiscardPile(List<Card> discardPile) {
        this.discardPile = discardPile;
    }
	/**
     * Sets the top card of the discard pile.
     * @param card The card to set as the top of the discard pile.
     */
    public void setTopCard(Card card) {
        discardPile.add(card);
    }
    
    /**
     * Gets the top card of the discard pile.
     * @return The current top card on the discard pile.
     */
    public Card getTopCard() {
        if (discardPile.isEmpty()) {
            return null;
        }
        return getDiscardPile().get(getDiscardPile().size() - 1);
    }

    /**
     * Gets the current player index.
     * @return The index of the current player.
     */
    public int getCurrentPlayerIndex() {
        return currentPlayerIndex;
    }

    /**
     * Sets the current player index.
     * @param currentPlayerIndex The index to set as the current player.
     */
    public void setCurrentPlayerIndex(int currentPlayerIndex) {
        this.currentPlayerIndex = currentPlayerIndex;
    }

    /**
     * Sets the game direction.
     * @param gameDirection The direction to set for the game.
     */
    public void setGameDirection(Direction gameDirection) {
        this.gameDirection = gameDirection;
    }
    
    /**
     * Sets the current colour in play to a new random colour, excluding Colour.WILD.
     */
    public void setRandomColour() {
        Random random = new Random();
        Colour[] colors = {Colour.BLUE, Colour.RED, Colour.YELLOW, Colour.GREEN, };
        setCurrentColour(colors[random.nextInt(colors.length)]);
    }

	/**
     * Constructs a GameSession with the given players and a starting set of cards for the draw pile.
     * @param players List of players participating in the game.
     * @param initialDrawPile Initial list of cards forming the draw pile.
     */
    public GameSession(List<Player> players, List<Card> initialDrawPile) {
        setPlayers(players);
        setDrawPile(new ArrayList<>(initialDrawPile));
        setDiscardPile(new ArrayList<>());
        setCurrentPlayerIndex(0);
        setGameDirection(Direction.CLOCKWISE);
    }

    /**
     * Adds a card to the discard pile.
     * @param card The card to be added to the discard pile.
     */
    public void addCardToDiscardPile(Card card) {
        getDiscardPile().add(card);
    }
    
    /**
     * Checks if the draw pile is empty.
     * @return true if there are no cards left in the draw pile, false otherwise.
     */
    public boolean isDrawPileEmpty() {
        return getDrawPile().isEmpty();
    }
    
    /**
     * Checks if the discard pile is empty.
     * @return true if there are no cards left in the discard pile, false otherwise.
     */
    public boolean isDiscardPileEmpty() {
        return getDiscardPile().isEmpty();
    }

    /**
     * Draws a card from the draw pile.
     * @return The card drawn from the draw pile.
     */
    public Card drawCard() {
        if (drawPile.isEmpty()) {
            System.out.println("Draw pile is empty. Attempting to reshuffle...");
            reshuffleDiscardIntoDraw();
        }
        if (!drawPile.isEmpty()) {
            Card drawnCard = drawPile.remove(drawPile.size() - 1);
            System.out.println("Drew a card: " + drawnCard);
            return drawnCard;
        }
        System.out.println("No cards left to draw after reshuffle attempt.");
        return null; // or consider handling this situation more gracefully
    }
    
    /**
     * Draws a specific number of cards from the draw pile.
     * @param numberOfCards The number of cards to draw.
     * @return A list of drawn cards.
     */
    
    public List<Card> drawCards(int numberOfCards) {
        List<Card> drawnCards = new ArrayList<>();

        for (int i = 0; i < numberOfCards; i++) {
            if (getDrawPile().isEmpty()) {
                System.out.println("Draw pile is empty before drawing card " + (i+1) + ". Attempting to reshuffle...");
                reshuffleDiscardIntoDraw();
            }
            if (!getDrawPile().isEmpty()) {
                Card drawnCard = getDrawPile().remove(getDrawPile().size() - 1);
                drawnCards.add(drawnCard);
                System.out.println("Drew card: " + drawnCard);
            } else {
                System.out.println("No cards left to draw after attempting reshuffle.");
                break; // Break the loop if no cards are available after reshuffle
            }
        }

        return drawnCards;
    }
    

    /**
     * Shuffles the discard pile back into the draw pile when the draw pile is empty.
     */
    private void reshuffleDiscardIntoDraw() {
        if (getDiscardPile().size() > 1) {
            Card topCard = getDiscardPile().remove(getDiscardPile().size() - 1);  // Keep the top card aside

            Collections.shuffle(getDiscardPile());  // Shuffle the remaining discard pile
            getDrawPile().addAll(getDiscardPile());      // Move all cards to the draw pile
            getDiscardPile().clear();               // Clear the discard pile
            getDiscardPile().add(topCard);          // Put the top card back on the discard pile

            System.out.println("The discard pile has been reshuffled into the draw pile.");
        }
        
        else if (discardPile.size() == 1) {
        	System.out.println("Not enough cards to reshuffle; only one card in discard pile.");
        }
        else {
            System.out.println("No cards available to reshuffle.");
        }
    }

    /**
     * Changes the current direction of play.
     */
    public void changePlayDirection() {
        gameDirection = (gameDirection == Direction.CLOCKWISE) ? Direction.COUNTERCLOCKWISE : Direction.CLOCKWISE;
    }

    /**
     * Advances the play turn to the next player, considering the current direction of play.
     */
    public void advancePlayTurn() {
        if (gameDirection == Direction.CLOCKWISE) {
            currentPlayerIndex++;
            if (currentPlayerIndex >= players.size()) {
                currentPlayerIndex = 0;
            }
        } 
        else {
            currentPlayerIndex--;
            if (currentPlayerIndex < 0) {
                currentPlayerIndex = players.size() - 1;
            }
        }
    }
    
    /**
     * Checks if the player has declared Uno when they are supposed to.
     * @param player The player who is currently playing.
     * @param declaredUno A flag indicating whether the player has declared Uno.
     */
    public void issueUnoPenalty(Player player) {
        System.out.println(player.getName() + " is penalized for not declaring Uno!");
        drawCards(2);  // Player draws two penalty cards
    }

}


