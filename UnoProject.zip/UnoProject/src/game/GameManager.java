package game;

import players.Player;
import cards.CardDeck;
import cards.Card;
import java.util.List;

/**
 * GameManager class manages the overall game logic and coordination between different game components.
 */
public class GameManager {
    private GameSession currentGameSession;
    private RuleEngine ruleEngine;
    private List<Player> players;
    private CardDeck cardDeck;

    /**
     * Retrieves the rule engine associated with the game.
     * @return The rule engine currently used in the game.
     */
    public RuleEngine getRuleEngine() {
        return ruleEngine;
    }

    /**
     * Sets the rule engine for the game.
     * @param ruleEngine The rule engine to set for managing the game logic.
     */
    public void setRuleEngine(RuleEngine ruleEngine) {
        this.ruleEngine = ruleEngine;
    }

    /**
     * Gets the list of players currently participating in the game.
     * @return A list of players in the current game session.
     */
    public List<Player> getPlayers() {
        return players;
    }

    /**
     * Sets the list of players participating in the game.
     * @param players The list of players to be set for the game.
     */
    public void setPlayers(List<Player> players) {
        this.players = players;
    }

    /**
     * Retrieves the current card deck used in the game.
     * @return The card deck currently being used in the game.
     */
    public CardDeck getCardDeck() {
        return cardDeck;
    }

    /**
     * Sets the card deck for the game.
     * @param cardDeck The card deck to be used in the game.
     */
    public void setCardDeck(CardDeck cardDeck) {
        this.cardDeck = cardDeck;
    }

    /**
     * Sets the current game session.
     * @param currentGameSession The game session to set as the current active session.
     */
    public void setCurrentGameSession(GameSession currentGameSession) {
        this.currentGameSession = currentGameSession;
    }
    
    /**
     * Gets the current game session.
     * @return The current game session.
     */
    public GameSession getCurrentGameSession() {
        return currentGameSession;
    }

    /**
     * Advances to the next player's turn.
     */
    public void nextTurn() {
        currentGameSession.advancePlayTurn();
    }
    
    /**
     * Gets the current player based on the current player index.
     * @return The current player.
     */
    private Player getCurrentPlayer() {
        return players.get(currentGameSession.getCurrentPlayerIndex());
    }

	/**
     * Constructs a GameManager with a list of players.
     * @param players The list of players participating in the game.
     */
    public GameManager(List<Player> players) {
        setPlayers(players);
        setRuleEngine(new RuleEngine());
        setCardDeck(new CardDeck());
    }
    
    /**
     * Advances game play by processing the current player's turn.
     */
    public void processTurn() {
        Player currentPlayer = getCurrentPlayer();
        try {
            currentPlayer.playTurn(getCurrentGameSession(), getRuleEngine());
        } catch (Exception e) {
            System.out.println("Error processing turn: " + e.getMessage());
        }
    }

    /**
     * Starts a new game session by shuffling the deck, dealing cards, and initialising game session.
     */
    public void startNewGame() {
        getCardDeck().shuffle();
        List<List<Card>> initialHands = getCardDeck().dealInitialCards(getPlayers().size());
        setCurrentGameSession(new GameSession(getPlayers(), getCardDeck().getAllCards()));
        for (int i = 0; i < getPlayers().size(); i++) {
            players.get(i).getHand().addAll(initialHands.get(i));
        }
        currentGameSession.setCurrentPlayerIndex(0); 
        // processTurn(); 
    }
    
    
    


    /**
     * Handles the action of a player playing a card.
     * @param player The player who is playing the card.
     * @param card The card that is being played.
     */
    public void playCard(Player player, Card card) {
        if (getRuleEngine().isValidMove(card, getCurrentGameSession().getTopCard(), getCurrentGameSession().getCurrentColour())) {
            getCurrentGameSession().addCardToDiscardPile(card);
            player.removeCardFromHand(card);
            ruleEngine.applyCardEffect(card, currentGameSession);
            if (player.getHandSize() == 0) {
                endGame(player);
            } else {
                currentGameSession.advancePlayTurn();
            }
        } else {
            System.out.println("Invalid move: The card cannot be played.");
        }
    }
    
    


    /**
     * Ends the game, declaring a winner and resetting game state as needed.
     * @param winner The player who has won the game.
     */
    public void endGame(Player winner) {
        System.out.println(winner.getName() + " has won the game!");

        // Calculate scores for all players and update their score history.
        calculateAndUpdateScores(winner);

        // Optionally, log the game results.
        logGameResults(winner);

        // Reset the game state for a new game, if you plan to start another game.
        resetGameState();
    }

    /**
     * Calculate and update the scores based on the cards left in other players' hands.
     * @param winner The player who has won the game.
     */
    private void calculateAndUpdateScores(Player winner) {
        int score = 0;
        for (Player player : players) {
            if (player != winner) {
                for (Card card : player.getHand()) {
                    score += card.getValue();
                }
               // player.updateScore(-score);  // Deduct points based on remaining cards.
            }
        }
        winner.updateScore(score);  // Winner gains points based on cards left in other players' hands.
        System.out.println("Scores updated. " + winner.getName() + " gains " + score + " points.");
    }

    /**
     * Logs the game results for historical data and analysis.
     * @param winner The player who has won the game.
     */
    private void logGameResults(Player winner) {
        // This could write to a file or database. Example:
        System.out.println("Logging game results...");
        // Example log format: "Winner: [Winner's Name], Score: [Score]"
    }

    /**
     * Resets the game environment for potentially starting a new game.
     */
    private void resetGameState() {
        currentGameSession = null;  // Clear the current game session.
        cardDeck.reset();           // Prepare the deck for a new game.
        System.out.println("Game state has been reset.");
    }


   
}


