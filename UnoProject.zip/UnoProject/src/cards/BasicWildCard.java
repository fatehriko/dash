package cards;

import game.GameSession;

/**
 * Basic wild card that changes the current colour in play.
 */
public class BasicWildCard extends WildCard {
	
	public BasicWildCard() {
	       super();
	   }
	
	/**
     * Implements the play behaviour for a basic Wild card, which involves setting the colour to be played next.
     * @param gameSession Session of the game where this type of cards' effects will be applied.
     */
    @Override
    public void play(GameSession gameSession) {
    	gameSession.setRandomColour();
    }
}

	 
	 

