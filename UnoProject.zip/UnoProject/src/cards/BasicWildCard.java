package cards;

/**
 * Basic wild card that changes the current colour in play.
 */
public class BasicWildCard extends WildCard {
	
	public BasicWildCard() {
	       super();
	   }

    @Override
    public String getImagePath() {
        return "/src/gui/images/wild-basic.png";
    }
}
