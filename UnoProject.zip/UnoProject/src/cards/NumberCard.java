package cards;

import game.GameSession;

/**
 * Represents a Number card in the game.
 * Each Number card has its own colour and number between 0 and 9.
 */
public class NumberCard extends Card {
	
    private int number;
    
    /**
     * Gets the number on this card.
     * @return The number on this card.
     */
    public int getNumber() {
        return number;
    }
    
    /**
     * Sets the number on this card.
     * @param number The number on this card.
     */

    public void setNumber(int number) {
		this.number = number;
	}

	/**
     * Constructor for the NumberCard class.
     * @param colour The colour of the card.
     * @param number The number on the card.
     */
    public NumberCard(Colour colour, int number) {
        super(colour, number);
        setNumber(number);
    }

    /**
     * Implements the play method to handle the action when this card is played.
     * This method applies different effects based on the type of the action card.
     * @param gameSession Session of the game where this type of cards' effects will be applied.
     */
    @Override
    public void play(GameSession gameSession) { 
        gameSession.setTopCard(this);
        gameSession.advancePlayTurn();
    }

    @Override
    public String toString() {
        return "NumberCard{" +
               "colour=" + colour +
               ", number=" + number +
               ", value=" + value +
               '}';
    }
}

