package cards;

import game.GameSession;

/**
 * Abstract class representing a generic card in the game.
 * This class provides template for all types of cards.
 */

public abstract class Card {

    public enum Colour {
        RED, YELLOW, BLUE, GREEN, WILD; 
    }

    protected Colour colour;
    protected int value; 

    /**
     * Constructor for the Card class.
     * @param colour The colour of the card.
     * @param value The value of the card.
     */
    public Card(Colour colour, int value) {
        this.colour = colour;
        this.value = value;
    }
    

    /**
     * Gets the colour of the card.
     * @return The colour of the card.
     */
    public Colour getColor() {
        return colour;
    }

    /**
     * Gets the value of the card.
     * @return The value of the card.
     */
    public int getValue() {
        return value;
    }

    /**
     * Abstract method to play the card.
     * Specific actions will be defined in subclasses.
     * @param gameSession Session of the game where the card's effects will be applied.
     */
//    public abstract void play(GameSession gameSession);

    /**
     * Returns a string representation of the card.
     * @return String that represents the card's details.
     */
    @Override
    public String toString() {
        return "Card{" +
               "colour=" + colour +
               ", value=" + value +
               '}';
    }
}
