package cards;

import game.GameSession;

/**
 * Represents an action card in the game.
 * These cards include Skip, Reverse, and Draw Two, each having special effects.
 */

public class ActionCard extends Card {
	public enum ActionType {
		SKIP, REVERSE, DRAW_TWO
	}
	
	private ActionType actionType;
	
	/**
     * Gets the type of action this card performs.
     * @return The ActionType of this card.
     */
    public ActionType getActionType() {
        return actionType;
    }
    
    /**
     * Sets the type of action this card performs.
     * @param actionType The type of action this card performs.
     */
	
	public void setActionType(ActionType actionType) {
		this.actionType = actionType;
	}
	

	/**
	 * Constructor for the ActionCard class.
	 * @param colour The colour of the action card
	 * @param actionType The type of action this card performs.
	 */
	public ActionCard(Colour colour, ActionType actionType) {
		 super(colour, 20);
	     setActionType(actionType);
	    }

	    /**
	     * Implements the play method to handle the action when this card is played.
	     * This method applies different effects based on the type of the action card.
	     * @param gameSession Session of the game where this type of cards' effects will be applied.
	     */
	    @Override
	    public void play(GameSession gameSession) {
	        switch (actionType) {
	            case SKIP:
	                gameSession.advancePlayTurn();
	                gameSession.advancePlayTurn();
	                break;
	            case REVERSE:
	                gameSession.changePlayDirection();
	                gameSession.advancePlayTurn();
	                break;
	            case DRAW_TWO:
	                gameSession.advancePlayTurn();
	                gameSession.drawCards(2);
	                gameSession.advancePlayTurn();
	                break;
	            default:
	                throw new IllegalArgumentException("Unexpected action type: " + actionType);
	        }
	    }

	    @Override
	    public String toString() {
	        return "ActionCard{" +
	               "colour=" + colour +
	               ", actionType=" + actionType +
	               ", value=" + value +
	               '}';
	    }
	}
