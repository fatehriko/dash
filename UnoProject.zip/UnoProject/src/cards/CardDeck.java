package cards;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Manages the deck of cards, shuffling and dealing.
 */
public class CardDeck {
    private List<Card> cards;

    /**
     * Gets the list of the cards.
     * @return The list of the cards.
     */
    public List<Card> getCards() {
		return cards;
	}
    
    /**
     * Sets the list of the cards.
     * @param cards The list of the cards.
     */
	public void setCards(List<Card> cards) {
		this.cards = cards;
	}
	
	/**
     * Gets a copy of all the cards in the deck.
     * @return A list containing all the cards in the deck.
     */
    public List<Card> getAllCards() {
        return new ArrayList<>(cards);
    }

	/**
     * Constructs a new deck and initialises it with all cards.
     */
    public CardDeck() {
        setCards(new ArrayList<>());
        initializeDeck();
        shuffle();
    }
    
    /**
     * Resets the deck to its initial full state with all cards and shuffles them.
     */
    public void reset() {
        cards = new ArrayList<>();  
        initializeDeck();        
        shuffle();          
        System.out.println("Card deck has been reset and shuffled.");
    }

    /**
     * Initialises the deck with a standard set of cards.
     */
    private void initializeDeck() {
        for (Card.Colour color : Card.Colour.values()) {
            if (color != Card.Colour.WILD) {  
                getCards().add(new NumberCard(color, 0)); 
                for (int i = 1; i <= 9; i++) {
                	getCards().add(new NumberCard(color, i));
                	getCards().add(new NumberCard(color, i));  
                }
            }
        }
        
        for (Card.Colour color : Card.Colour.values()) {
            if (color != Card.Colour.WILD) {
            	getCards().add(new ActionCard(color, ActionCard.ActionType.DRAW_TWO));
            	getCards().add(new ActionCard(color, ActionCard.ActionType.SKIP));
            	getCards().add(new ActionCard(color, ActionCard.ActionType.REVERSE));
            	getCards().add(new ActionCard(color, ActionCard.ActionType.DRAW_TWO));
            	getCards().add(new ActionCard(color, ActionCard.ActionType.SKIP));
            	getCards().add(new ActionCard(color, ActionCard.ActionType.REVERSE));

            }
        }

        for (int i = 0; i < 4; i++) {
        	getCards().add(new BasicWildCard());
        	getCards().add(new SpecialWildCard());
        }
    }

    /**
     * Shuffles the deck of cards.
     */
    public void shuffle() {
        Collections.shuffle(getCards());
    }

    /**
     * Draws a card from the top of the deck.
     * @return The card drawn from the deck.
     */
    public Card drawCard() {
        if (!getCards().isEmpty()) {
            return getCards().remove(getCards().size() - 1);
        }
        return null;
    }

    /**
     * Deals the initial set of cards to players.
     * @param numberOfPlayers The number of players in the game.
     * @return A list of lists containing the initial cards for each player.
     */
    public List<List<Card>> dealInitialCards(int numberOfPlayers) {
        List<List<Card>> playerCards = new ArrayList<>();
        for (int i = 0; i < numberOfPlayers; i++) {
            List<Card> hand = new ArrayList<>();
            for (int j = 0; j < 7; j++) {
                if (!cards.isEmpty()) 
                    hand.add(drawCard());
            }
            playerCards.add(hand);
        }
        return playerCards;
    }
}

