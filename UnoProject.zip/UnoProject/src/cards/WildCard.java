package cards;

import game.GameSession;

/**
 * Base class for wild cards in the game.
 */
public abstract class WildCard extends Card {
	
	/**
     * Constructs a WildCard with a default value of 50.
     */
	public WildCard() {
        super(Colour.WILD, 50);
    }

    /**
     * Each wild card will implement its own play behaviour.
     */
    @Override
    public abstract void play(GameSession gameSession);

    @Override
    public String toString() {
        return "WildCard{" + "color=" + getColor() + "}";
    }
}
