package cards;

/**
 * Represents a Wild Draw Four card which changes the colour and makes the next player to draw four cards and skip their turn.
 */

public class SpecialWildCard extends WildCard {
	
	/**
     * Constructs a Wild Draw Four Card.
     */
    public SpecialWildCard() {
        super();
    }

    @Override
    public String getImagePath() {
        return "/src/gui/images/wild-special.png";
    }
}
