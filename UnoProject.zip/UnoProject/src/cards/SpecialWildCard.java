package cards;

import game.GameSession;

/**
 * Represents a Wild Draw Four card which changes the colour and makes the next player to draw four cards and skip their turn.
 */

public class SpecialWildCard extends WildCard {
	
	/**
     * Constructs a Wild Draw Four Card.
     */
    public SpecialWildCard() {
        super();
    }
    
    /**
     * Implements the play method to handle the action when this card is played.
     * @param gameSession Session of the game where this type of cards' effects will be applied.
     */
//    @Override
//    public void play(GameSession gameSession) {
//    	gameSession.setRandomColour();
//        gameSession.advancePlayTurn();
//        gameSession.drawCard();
//        gameSession.drawCard();
//        gameSession.drawCard();
//        gameSession.drawCard();
//        gameSession.advancePlayTurn();
//    }

}