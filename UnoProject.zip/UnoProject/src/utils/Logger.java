package utils;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Logger class for logging events and actions in the Uno game.
 */
public class Logger {
    private static final String LOG_FILE = "game_log.txt";  // Default log file name
    private static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); // For timestamping

    /**
     * Writes a log message to the log file with a timestamp.
     * @param message The message to log.
     */
    public static void log(String message) {
        String timestamp = dateFormat.format(new Date()); // Current time and date
        String logMessage = timestamp + " - " + message;  // Combine timestamp with message

        try {
            FileHandler.writeFile(LOG_FILE, logMessage, true);  // Append message to the log file
        } 
        catch (IOException e) {
            System.err.println("Error writing to log file: " + e.getMessage());
        }
    }
}

