package utils;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Logger class for logging events and actions in the game.
 */
public class Logger {
    private static final String LOG_FILE = "game_log.txt";
    private static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    /**
     * Writes a log message to the log file with a timestamp.
     * @param message The message to log.
     */
    public static void log(String message) {
        String timestamp = dateFormat.format(new Date());
        String logMessage = timestamp + " - " + message;

        try {
            FileHandler.writeFile(LOG_FILE, logMessage, true);  // Append message to the log file
        } 
        catch (IOException e) {
//        	Logger.log("Salam");
            System.err.println("Error writing to log file: " + e.getMessage());
        }
    }
}

