package utils;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * FileHandler class to manage file I/O operations.
 */
public class FileHandler {

    /**
     * Writes the specified content to a file.
     * @param filename The name of the file to write to.
     * @param content The content to write to the file.
     * @param append If true, the content will be appended to the file; if false, the file will be overwritten.
     * @throws IOException If an I/O error occurs.
     */
    public static void writeFile(String filename, String content, boolean append) throws IOException {
        try (FileWriter fw = new FileWriter(filename, append);
            BufferedWriter bw = new BufferedWriter(fw)) {
            bw.write(content);
            bw.newLine();
        }
    }

    /**
     * Reads all lines from a specified file.
     * @param filename The name of the file to read from.
     * @return A list of strings, each representing a line in the file.
     * @throws IOException If an I/O error occurs.
     */
    public static List<String> readFile(String filename) throws IOException {
        List<String> lines = new ArrayList<>();
        try (FileReader fr = new FileReader(filename);
            BufferedReader br = new BufferedReader(fr)) {
            String line;
            while ((line = br.readLine()) != null) {
                lines.add(line);
            }
        }
        return lines;
    }
}
