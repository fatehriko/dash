package utils;

/**
 * Validator class provides utility methods for validating input data in the Uno game.
 */
public class Validator {

    /**
     * Validates if the provided string is a valid player name.
     * A valid player name is not null, not empty, and not too long.
     * @param playerName The player name to validate.
     * @return true if the name is valid, false otherwise.
     */
    public static boolean isValidPlayerName(String playerName) {
        return playerName != null && !playerName.trim().isEmpty() && playerName.length() <= 50;
    }

    /**
     * Validates if the number of players is within the allowed range for the game.
     * @param numberOfPlayers The number of players to validate.
     * @return true if the number is within the range, false otherwise.
     */
    public static boolean isValidNumberOfPlayers(int numberOfPlayers) {
        return numberOfPlayers >= 2 && numberOfPlayers <= 10;
    }

    /**
     * Validates that a selected card index is within the bounds of the player's hand.
     * @param index The index to validate.
     * @param handSize The size of the player's hand.
     * @return true if the index is within the bounds, false otherwise.
     */
    public static boolean isValidCardIndex(int index, int handSize) {
        return index >= 0 && index < handSize;
    }
}

