package tests;

import game.GameManager;
import game.GameSession;
import game.RuleEngine;
import players.ComputerPlayer;
import players.Player;
import cards.CardDeck;
import cards.Card;
import cards.NumberCard;
import cards.ActionCard;
import cards.WildCard;
import cards.SpecialWildCard;
import cards.BasicWildCard;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class GameLogicTest {

    GameManager gameManager;
    List<Player> players;
    GameSession session;
    RuleEngine ruleEngine;
    
    private static final int MAX_TURNS = 70;  // Set a maximum number of turns to prevent infinite loops

    public GameLogicTest() {
        setupGame();
        simulateGame();
    }

    private void setupGame() {
        ComputerPlayer bot1 = new ComputerPlayer("Bot1");
        ComputerPlayer bot2 = new ComputerPlayer("Bot2");
        ComputerPlayer bot3 = new ComputerPlayer("Bot3");
        players = Arrays.asList(bot1, bot2, bot3);

        ruleEngine = new RuleEngine();
        gameManager = new GameManager(players);
        gameManager.startNewGame();
        session = gameManager.getCurrentGameSession();
    }

    private void simulateGame() {
        System.out.println("Starting Uno Game Simulation...");
        int turns = 0;
        while (turns < MAX_TURNS && !isGameOver()) {
            Player currentPlayer = gameManager.getCurrentGameSession().getPlayers().get(session.getCurrentPlayerIndex());
            Card topCard = session.getTopCard();

            // Display turn, current player, top card, and current hand
            System.out.printf("\nTurn %d: %s's move (Top Card: %s)\n", turns + 1, currentPlayer.getName(), cardToString(topCard));
            System.out.println("Current hand: " + currentPlayer.getHand().stream()
                .map(this::cardToString)
                .collect(Collectors.joining(", ")));

            // Display all players' hands
            gameManager.getCurrentGameSession().getPlayers().forEach(player -> {
                System.out.println(player.getName() + "'s hand: " + player.getHand().stream()
                    .map(this::cardToString)
                    .collect(Collectors.joining(", ")));
            });

            // Display discard pile and draw pile states
            System.out.println("Discard Pile: " + session.getDiscardPile().stream()
                .map(this::cardToString)
                .collect(Collectors.joining(", ")));
            System.out.println("Draw Pile: " + session.getDrawPile().size() + " cards remaining");

            // Simulate player taking their turn
            currentPlayer.playTurn(session, ruleEngine);

            // Advance to the next player
            session.advancePlayTurn();
            turns++;
        }
        if (turns >= MAX_TURNS) {
            System.out.println("Game stopped due to reaching turn limit.");
        } else {
            System.out.println("Game Over - a player has won!");
        }
    }

    private String cardToString(Card card) {
        if (card instanceof NumberCard) {
            return card.getColor().toString().substring(0, 1) + ((NumberCard) card).getNumber();
        } else if (card instanceof ActionCard) {
            return card.getColor().toString().substring(0, 1) + ((ActionCard) card).getActionType().toString().charAt(0);
        } else if (card instanceof BasicWildCard) {
            return "W";
        } else if (card instanceof SpecialWildCard) {
            return "W4";
        }
        return "Unknown";
    }

    private boolean isGameOver() {
        return session.getPlayers().stream().anyMatch(player -> player.getHandSize() == 0);
    }

    public static void main(String[] args) {
        new GameLogicTest();
    }
}



