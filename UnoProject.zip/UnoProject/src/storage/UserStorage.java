package storage;

import players.HumanPlayer;
import players.Player;
import utils.FileHandler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * UserStorage class for handling the persistence of user data.
 */
public class UserStorage {

    private static final String filename = "user_data.txt";

    /**
     * Saves user data to a file.
     * @param players The list of players to save.
     */
    public static void saveUserData(List<Player> players) {
        List<String> lines = new ArrayList<>();
        for (Player player : players) {
            lines.add(formatPlayer(player));
        }
        try {
            FileHandler.writeFile(filename, String.join("\n", lines), false);
        } catch (IOException e) {
            System.err.println("Error writing user data to file: " + e.getMessage());
        }
    }

    /**
     * Loads user data from a file.
     * @return The list of loaded players.
     */
    public static List<Player> loadUserData() {
        List<Player> players = new ArrayList<>();
        try {
            List<String> lines = FileHandler.readFile(filename);
            for (String line : lines) {
                players.add(parsePlayer(line));
            }
        } catch (IOException e) {
            System.err.println("Error reading user data from file: " + e.getMessage());
        }
        return players;
    }

    /**
     * Converts a Player object to a formatted string.
     * @param player The player to format.
     * @return A formatted string representing the player.
     */
    private static String formatPlayer(Player player) {
        return String.join(",",
                player.getName(),
                Integer.toString(player.getScore()),
                Integer.toString(player.getWins()),
                Integer.toString(player.getLosses()),
                Integer.toString(player.getGamesPlayed()),
                Integer.toString(player.getTotalScore()));
    }

    /**
     * Parses a formatted string to create a Player object.
     * @param line The formatted string representing a player.
     * @return The Player object.
     */
    private static Player parsePlayer(String line) {
        String[] parts = line.split(",");
        HumanPlayer player = new HumanPlayer(parts[0]);
        player.setScore(Integer.parseInt(parts[1]));
        player.setWins(Integer.parseInt(parts[2]));
        player.setLosses(Integer.parseInt(parts[3]));
        player.setGamesPlayed(Integer.parseInt(parts[4]));
        player.setTotalScore(Integer.parseInt(parts[5]));
        return player;
    }
}


