package storage;

import players.Player;
import java.io.*;
import java.util.List;

/**
 * UserStorage class for handling the persistence of user data.
 */
public class UserStorage {

    /**
     * Saves user data to a file.
     * @param players The list of players to save.
     * @param filename The file to save the user data to.
     * @throws IOException If there is an issue writing to the file.
     */
    public static void saveUserData(List<Player> players, String filename) throws IOException {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(filename))) {
            out.writeObject(players);
        }
    }

    /**
     * Loads user data from a file.
     * @param filename The file to load the user data from.
     * @return The list of loaded players.
     * @throws IOException If there is an issue reading from the file.
     * @throws ClassNotFoundException If the class of a serialized object cannot be found.
     */
    public static List<Player> loadUserData(String filename) throws IOException, ClassNotFoundException {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(filename))) {
            return (List<Player>) in.readObject();
        }
    }
}
