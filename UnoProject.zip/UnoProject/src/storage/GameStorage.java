package storage;

import game.GameSession;
import java.io.*;

/**
 * GameStorage class for handling the persistence of game sessions.
 */
public class GameStorage {

    /**
     * Saves the current game session to a file.
     * @param gameSession The game session to save.
     * @param filename The file to save the game session to.
     * @throws IOException If there is an issue writing to the file.
     */
    public static void saveGameSession(GameSession gameSession, String filename) throws IOException {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(filename))) {
            out.writeObject(gameSession);
        }
    }

    /**
     * Loads a game session from a file.
     * @param filename The file to load the game session from.
     * @return The loaded game session.
     * @throws IOException If there is an issue reading from the file.
     * @throws ClassNotFoundException If the class of a serialized object cannot be found.
     */
    public static GameSession loadGameSession(String filename) throws IOException, ClassNotFoundException {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(filename))) {
            return (GameSession) in.readObject();
        }
    }
}
