package storage;

import game.GameSession;
import players.Player;
import players.HumanPlayer;
import cards.Card;
import cards.NumberCard;
import cards.ActionCard;
import cards.BasicWildCard;
import cards.SpecialWildCard;
import utils.FileHandler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * GameStorage class for handling the persistence of game sessions.
 */
public class GameStorage {
	
	private static final String filename = "game_data.txt";

    /**
     * Saves the current game session to a file.
     * @param gameSession The game session to save.
     * @param filename The file to save the game session to.
     */
    public static void saveGameSession(GameSession gameSession) {
        List<String> lines = new ArrayList<>();
        lines.add(formatGameSession(gameSession));
        try {
            FileHandler.writeFile(filename, String.join("\n", lines), false);
        } catch (IOException e) {
            System.err.println("Error writing game session to file: " + e.getMessage());
        }
    }

    /**
     * Loads a game session from a file.
     * @param filename The file to load the game session from.
     * @return The loaded game session.
     */
    public static GameSession loadGameSession() {
        try {
            List<String> lines = FileHandler.readFile(filename);
            if (!lines.isEmpty()) {
                return parseGameSession(lines.get(0));
            }
        } catch (IOException e) {
            System.err.println("Error reading game session from file: " + e.getMessage());
        }
        return null;
    }

    /**
     * Converts a GameSession object to a formatted string.
     * @param gameSession The game session to format.
     * @return A formatted string representing the game session.
     */
    private static String formatGameSession(GameSession gameSession) {
        StringBuilder sb = new StringBuilder();
        sb.append(gameSession.getCurrentPlayerIndex()).append(";");
        sb.append(gameSession.getGameDirection()).append(";");
        sb.append(gameSession.getCurrentColour()).append(";");

        for (Player player : gameSession.getPlayers()) {
            sb.append(player.getName()).append(",");
            for (Card card : player.getHand()) {
                sb.append(card.getColor()).append("-").append(card.getValue()).append(",");
            }
            sb.append(";");
        }

        for (Card card : gameSession.getDrawPile()) {
            sb.append(card.getColor()).append("-").append(card.getValue()).append(",");
        }
        sb.append(";");

        for (Card card : gameSession.getDiscardPile()) {
            sb.append(card.getColor()).append("-").append(card.getValue()).append(",");
        }
        return sb.toString();
    }

    /**
     * Parses a formatted string to create a GameSession object.
     * @param line The formatted string representing a game session.
     * @return The GameSession object.
     */
    private static GameSession parseGameSession(String line) {
        String[] parts = line.split(";");
        int currentPlayerIndex = Integer.parseInt(parts[0]);
        GameSession.Direction gameDirection = GameSession.Direction.valueOf(parts[1]);
        Card.Colour currentColour = Card.Colour.valueOf(parts[2]);

        List<Player> players = new ArrayList<>();
        String[] playerParts = parts[3].split(",");
        for (String playerPart : playerParts) {
            String[] playerInfo = playerPart.split(",");
            HumanPlayer player = new HumanPlayer(playerInfo[0]);
            for (int i = 1; i < playerInfo.length; i++) {
                String[] cardInfo = playerInfo[i].split("-");
                Card.Colour cardColour = Card.Colour.valueOf(cardInfo[0]);
                int cardValue = Integer.parseInt(cardInfo[1]);
                Card card;
                if (cardValue >= 0 && cardValue <= 9) {
                    card = new NumberCard(cardColour, cardValue);
                } else if (cardValue == 20) {
                    card = new ActionCard(cardColour, ActionCard.ActionType.valueOf(cardInfo[2]));
                } else if (cardValue == 50) {
                    if (cardInfo.length == 3 && cardInfo[2].equals("W4")) {
                        card = new SpecialWildCard();
                    } else {
                        card = new BasicWildCard();
                    }
                } else {
                    throw new IllegalArgumentException("Unexpected card value: " + cardValue);
                }
                player.addCardToHand(card);
            }
            players.add(player);
        }

        List<Card> drawPile = new ArrayList<>();
        String[] drawPileParts = parts[4].split(",");
        for (String drawPilePart : drawPileParts) {
            String[] cardInfo = drawPilePart.split("-");
            Card.Colour cardColour = Card.Colour.valueOf(cardInfo[0]);
            int cardValue = Integer.parseInt(cardInfo[1]);
            Card card;
            if (cardValue >= 0 && cardValue <= 9) {
                card = new NumberCard(cardColour, cardValue);
            } else if (cardValue == 20) {
                card = new ActionCard(cardColour, ActionCard.ActionType.valueOf(cardInfo[2]));
            } else if (cardValue == 50) {
                if (cardInfo.length == 3 && cardInfo[2].equals("W4")) {
                    card = new SpecialWildCard();
                } else {
                    card = new BasicWildCard();
                }
            } else {
                throw new IllegalArgumentException("Unexpected card value: " + cardValue);
            }
            drawPile.add(card);
        }

        List<Card> discardPile = new ArrayList<>();
        String[] discardPileParts = parts[5].split(",");
        for (String discardPilePart : discardPileParts) {
            String[] cardInfo = discardPilePart.split("-");
            Card.Colour cardColour = Card.Colour.valueOf(cardInfo[0]);
            int cardValue = Integer.parseInt(cardInfo[1]);
            Card card;
            if (cardValue >= 0 && cardValue <= 9) {
                card = new NumberCard(cardColour, cardValue);
            } else if (cardValue == 20) {
                card = new ActionCard(cardColour, ActionCard.ActionType.valueOf(cardInfo[2]));
            } else if (cardValue == 50) {
                if (cardInfo.length == 3 && cardInfo[2].equals("W4")) {
                    card = new SpecialWildCard();
                } else {
                    card = new BasicWildCard();
                }
            } else {
                throw new IllegalArgumentException("Unexpected card value: " + cardValue);
            }
            discardPile.add(card);
        }

        GameSession gameSession = new GameSession(players, drawPile);
        gameSession.setCurrentPlayerIndex(currentPlayerIndex);
        gameSession.setGameDirection(gameDirection);
        gameSession.setCurrentColour(currentColour);
        gameSession.setDrawPile(drawPile);
        gameSession.setDiscardPile(discardPile);

        return gameSession;
    }
}
