package main;

import gui.LoginWindow;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

public class Main extends JFrame {

	public Main() {
		setTitle("UNO Start Screen");
		setSize(1080, 720); // Set the size to match the image aspect ratio
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);

		// Create a panel with a background image
		BackgroundPanel backgroundPanel = new BackgroundPanel();
		backgroundPanel.setLayout(null);
		getContentPane().add(backgroundPanel);

		// Create an invisible button over the "Start" area of the image
		JButton startButton = new JButton();
		startButton.setBounds(80, 580, 220, 60); // Adjust these values to match the "Start" button position
		startButton.setOpaque(false);
		startButton.setContentAreaFilled(false);
		startButton.setBorderPainted(false);

		startButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new LoginWindow();
				dispose();
			}
		});

		backgroundPanel.add(startButton);

		setVisible(true);
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> new Main());
	}
}

class BackgroundPanel extends JPanel {

	private Image backgroundImage;

	public BackgroundPanel() {
		String imagePath = "C:\\Users\\ismay\\Downloads\\UnoProject\\UnoProject\\src\\gui\\images\\start-screen.png";
		File imageFile = new File(imagePath);

		if (imageFile.exists() && !imageFile.isDirectory()) {
			backgroundImage = new ImageIcon(imagePath).getImage();
			System.out.println("Image loaded successfully: " + imagePath);
		} else {
			System.err.println("Image file does not exist: " + imagePath);
		}
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		if (backgroundImage != null) {
			g.drawImage(backgroundImage, 0, 0, 1080, 720, this); // Ensure the image is scaled properly
		} else {
			g.setColor(Color.BLACK);
			g.fillRect(0, 0, this.getWidth(), this.getHeight());
			g.setColor(Color.WHITE);
			g.drawString("Image not found", this.getWidth() / 2 - 50, this.getHeight() / 2);
		}
	}
}
