package storage;

import players.HumanPlayer;
import players.Player;
import utils.FileHandler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserStorage {

    private static final String userDataFile = "C:\\Users\\ismay\\Downloads\\UnoProject\\UnoProject\\src\\user_data.txt";
    private static final String passwordDataFile = "C:\\Users\\ismay\\Downloads\\UnoProject\\UnoProject\\src\\password_data.txt";

    public static void saveUserData(List<Player> players) {
        List<String> lines = new ArrayList<>();
        for (Player player : players) {
            lines.add(formatPlayer(player));
        }
        try {
            FileHandler.writeFile(userDataFile, String.join("\n", lines), false);
        } catch (IOException e) {
            System.err.println("Error writing user data to file: " + e.getMessage());
        }
    }

    public static List<Player> loadUserData() {
        List<Player> players = new ArrayList<>();
        try {
            List<String> lines = FileHandler.readFile(userDataFile);
            for (String line : lines) {
                players.add(parsePlayer(line));
            }
        } catch (IOException e) {
            System.err.println("Error reading user data from file: " + e.getMessage());
        }
        return players;
    }

    public static void savePasswords(Map<String, String> passwords) {
        List<String> lines = new ArrayList<>();
        for (Map.Entry<String, String> entry : passwords.entrySet()) {
            lines.add(entry.getKey() + "," + entry.getValue());
        }
        try {
            FileHandler.writeFile(passwordDataFile, String.join("\n", lines), false);
        } catch (IOException e) {
            System.err.println("Error writing password data to file: " + e.getMessage());
        }
    }

    public static Map<String, String> loadPasswords() {
        Map<String, String> passwords = new HashMap<>();
        try {
            List<String> lines = FileHandler.readFile(passwordDataFile);
            for (String line : lines) {
                String[] parts = line.split(",");
                if (parts.length == 2) {
                    passwords.put(parts[0], parts[1]);
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading password data from file: " + e.getMessage());
        }
        return passwords;
    }

    private static String formatPlayer(Player player) {
        return String.join(",",
                player.getName(),
                Integer.toString(player.getScore()),
                Integer.toString(player.getWins()),
                Integer.toString(player.getLosses()),
                Integer.toString(player.getGamesPlayed()),
                Integer.toString(player.getTotalScore()));
    }

    private static Player parsePlayer(String line) {
        String[] parts = line.split(",");
        HumanPlayer player = new HumanPlayer(parts[0]);
        player.setScore(Integer.parseInt(parts[1]));
        player.setWins(Integer.parseInt(parts[2]));
        player.setLosses(Integer.parseInt(parts[3]));
        player.setGamesPlayed(Integer.parseInt(parts[4]));
        player.setTotalScore(Integer.parseInt(parts[5]));
        return player;
    }
}
