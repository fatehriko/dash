package storage;

import game.GameSession;
import players.Player;
import players.HumanPlayer;
import players.ComputerPlayer;
import cards.Card;
import cards.NumberCard;
import cards.ActionCard;
import cards.BasicWildCard;
import cards.SpecialWildCard;
import utils.FileHandler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class GameStorage {

    private static final String sessionNamesFile = "C:\\Users\\ismay\\Downloads\\UnoProject\\UnoProject\\src\\session_names.txt";

    public static void saveGameSession(GameSession gameSession, String sessionName) {
        List<String> lines = new ArrayList<>();
        lines.add(formatGameSession(gameSession));
        try {
            FileHandler.writeFile(sessionName + ".txt", String.join("\n", lines), false);
            List<String> sessionNames = FileHandler.readFile(sessionNamesFile);
            if (!sessionNames.contains(sessionName)) {
                sessionNames.add(sessionName);
                FileHandler.writeFile(sessionNamesFile, String.join("\n", sessionNames), false);
            }
        } catch (IOException e) {
            System.err.println("Error writing game session to file: " + e.getMessage());
        }
    }

    public static GameSession loadGameSession(String sessionName) {
        try {
            List<String> lines = FileHandler.readFile(sessionName + ".txt");
            if (!lines.isEmpty()) {
                return parseGameSession(lines.get(0));
            }
        } catch (IOException e) {
            System.err.println("Error reading game session from file: " + e.getMessage());
        }
        return null;
    }

    private static String formatGameSession(GameSession gameSession) {
        StringBuilder sb = new StringBuilder();
        sb.append(gameSession.getCurrentPlayerIndex()).append(";");
        sb.append(gameSession.getGameDirection()).append(";");
        sb.append(gameSession.getCurrentColour()).append(";");

        for (Player player : gameSession.getPlayers()) {
            sb.append(player.getName()).append("-");
            for (Card card : player.getHand()) {
                sb.append(card.getColor()).append("-").append(card.getValue());
                if (card instanceof ActionCard) {
                    sb.append("-").append(((ActionCard) card).getActionType());
                }
                sb.append(",");
            }
            sb.append(";");
        }

        for (Card card : gameSession.getDrawPile()) {
            sb.append(card.getColor()).append("-").append(card.getValue());
            if (card instanceof ActionCard) {
                sb.append("-").append(((ActionCard) card).getActionType());
            }
            sb.append(",");
        }
        sb.append(";");

        for (Card card : gameSession.getDiscardPile()) {
            sb.append(card.getColor()).append("-").append(card.getValue());
            if (card instanceof ActionCard) {
                sb.append("-").append(((ActionCard) card).getActionType());
            }
            sb.append(",");
        }
        return sb.toString();
    }

    private static GameSession parseGameSession(String line) {
        System.out.println("Parsing game session: " + line); // Debug statement
        String[] parts = line.split(";");
        if (parts.length < 6) {
            throw new IllegalArgumentException("Invalid game session format.");
        }
        int currentPlayerIndex = Integer.parseInt(parts[0]);
        GameSession.Direction gameDirection = GameSession.Direction.valueOf(parts[1]);
        Card.Colour currentColour = Card.Colour.valueOf(parts[2]);

        List<Player> players = new ArrayList<>();
        String[] playerParts = parts[3].split(";");
        for (String playerPart : playerParts) {
            if (!playerPart.isEmpty()) {
                String[] playerInfo = playerPart.split("-", 2);
                String playerName = playerInfo[0];
                Player player;
                if (playerName.startsWith("Bot")) { // Adjust for your bot naming
                    player = new ComputerPlayer(playerName);
                } else {
                    player = new HumanPlayer(playerName);
                }
                if (playerInfo.length > 1 && !playerInfo[1].isEmpty()) {
                    String[] cardParts = playerInfo[1].split(",");
                    for (String cardPart : cardParts) {
                        if (!cardPart.isEmpty()) {
                            try {
                                Card card = parseCard(cardPart);
                                player.addCardToHand(card);
                            } catch (Exception e) {
                                System.err.println("Error parsing card: " + cardPart); // Debug statement
                                e.printStackTrace();
                            }
                        }
                    }
                }
                players.add(player);
            }
        }

        List<Card> drawPile = parseCardList(parts[4]);
        List<Card> discardPile = parseCardList(parts[5]);

        GameSession gameSession = new GameSession(players, drawPile);
        gameSession.setCurrentPlayerIndex(currentPlayerIndex);
        gameSession.setGameDirection(gameDirection);
        gameSession.setCurrentColour(currentColour);
        gameSession.setDrawPile(drawPile);
        gameSession.setDiscardPile(discardPile);

        return gameSession;
    }

    private static Card parseCard(String cardData) {
        String[] cardInfo = cardData.split("-");
        if (cardInfo.length < 2) {
            throw new IllegalArgumentException("Invalid card format: " + cardData);
        }
        Card.Colour cardColour = Card.Colour.valueOf(cardInfo[0]);
        int cardValue = Integer.parseInt(cardInfo[1]);
        if (cardValue >= 0 && cardValue <= 9) {
            return new NumberCard(cardColour, cardValue);
        } else if (cardValue == 20) {
            return new ActionCard(cardColour, ActionCard.ActionType.valueOf(cardInfo[2]));
        } else if (cardValue == 50) {
            if (cardInfo.length == 3 && "W4".equals(cardInfo[2])) {
                return new SpecialWildCard();
            } else {
                return new BasicWildCard();
            }
        } else {
            throw new IllegalArgumentException("Unexpected card value: " + cardValue);
        }
    }

    private static List<Card> parseCardList(String cardData) {
        List<Card> cardList = new ArrayList<>();
        String[] cardParts = cardData.split(",");
        for (String cardPart : cardParts) {
            if (!cardPart.isEmpty()) {
                try {
                    Card card = parseCard(cardPart);
                    cardList.add(card);
                } catch (Exception e) {
                    System.err.println("Error parsing card in list: " + cardPart); // Debug statement
                    e.printStackTrace();
                }
            }
        }
        return cardList;
    }
}
