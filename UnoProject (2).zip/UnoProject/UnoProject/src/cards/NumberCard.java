package cards;

/**
 * Represents a Number card in the game.
 * Each Number card has its own colour and number between 0 and 9.
 */
public class NumberCard extends Card {
	
    private int number;
    
    /**
     * Gets the number on this card.
     * @return The number on this card.
     */
    public int getNumber() {
        return number;
    }
    
    /**
     * Sets the number on this card.
     * @param number The number on this card.
     */

    public void setNumber(int number) {
		this.number = number;
	}

	/**
     * Constructor for the NumberCard class.
     * @param colour The colour of the card.
     * @param number The number on the card.
     */
    public NumberCard(Colour colour, int number) {
        super(colour, number);
        setNumber(number);
    }

    @Override
    public String getImagePath() {
        return String.format("C:\\Users\\ismay\\Downloads\\UnoProject\\UnoProject\\src\\gui\\images\\%s-%d.png", colour.toString().toLowerCase(), number);
    }

    @Override
    public String toString() {
        return "NumberCard{" +
               "colour=" + colour +
               ", number=" + number +
               '}';
    }
}
