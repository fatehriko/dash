package cards;

/**
 * Base class for wild cards in the game.
 */
public abstract class WildCard extends Card {
	
	/**
     * Constructs a WildCard with a default value of 50.
     */
	public WildCard() {
        super(Colour.WILD, 50);
    }

    @Override
    public String getImagePath() {
        // For Wild cards, you might need a specific naming convention
        // This assumes wild.png for BasicWildCard and wild_draw4.png for SpecialWildCard
        return "BasicWildCard".equals(this.getClass().getSimpleName()) ?
                "C:\\Users\\ismay\\Downloads\\UnoProject\\UnoProject\\src\\gui\\images\\wild.png" :
                "C:\\Users\\ismay\\Downloads\\UnoProject\\UnoProject\\src\\gui\\images\\wild_draw4.png";
    }

    @Override
    public String toString() {
        return "WildCard{" + "color=" + getColor() + "}";
    }
}
