package cards;

/**
 * Represents an action card in the game.
 * These cards include Skip, Reverse, and Draw Two, each having special effects.
 */

public class ActionCard extends Card {
	public enum ActionType {
		SKIP, REVERSE, DRAW_TWO
	}
	
	private ActionType actionType;
	
	/**
     * Gets the type of action this card performs.
     * @return The ActionType of this card.
     */
    public ActionType getActionType() {
        return actionType;
    }
    
    /**
     * Sets the type of action this card performs.
     * @param actionType The type of action this card performs.
     */
	
	public void setActionType(ActionType actionType) {
		this.actionType = actionType;
	}
	

	/**
	 * Constructor for the ActionCard class.
	 * @param colour The colour of the action card
	 * @param actionType The type of action this card performs.
	 */
	public ActionCard(Colour colour, ActionType actionType) {
		 super(colour, 20);
	     setActionType(actionType);
	    }

    @Override
    public String getImagePath() {
        String action = actionType.toString().toLowerCase().replace("_", ""); // To match file naming convention
        return String.format("C:\\Users\\ismay\\Downloads\\UnoProject\\UnoProject\\src\\gui\\images\\%s-%s.png", colour.toString().toLowerCase(), action);
    }

    @Override
    public String toString() {
        return "ActionCard{" +
               "colour=" + colour +
               ", actionType=" + actionType +
               '}';
    }
}
