package game;

import cards.CardDeck;
import players.Player;
import players.HumanPlayer;
import cards.Card;
import storage.UserStorage;
import java.util.List;

public class GameManager {
    private GameSession currentGameSession;
    private RuleEngine ruleEngine;
    private List<Player> players;
    private CardDeck cardDeck;

    public GameManager(List<Player> players) {
        this.players = players;
        this.ruleEngine = new RuleEngine();
        this.cardDeck = new CardDeck();
        this.currentGameSession = new GameSession(players, cardDeck.getAllCards());
    }

    public GameSession getCurrentGameSession() {
        return currentGameSession;
    }

    public void setCurrentGameSession(GameSession gameSession) {
        this.currentGameSession = gameSession;
    }

    public List<Player> getPlayers() {
        return players;
    }

    public void processTurn() {
        Player currentPlayer = players.get(currentGameSession.getCurrentPlayerIndex());
        currentPlayer.playTurn(currentGameSession, ruleEngine);
        if (currentPlayer.getHand().isEmpty()) {
            endGame(currentPlayer);
        } else {
            currentGameSession.advancePlayTurn();
        }
    }

    public void startNewGame() {
        cardDeck.reset();
        List<List<Card>> initialHands = cardDeck.dealInitialCards(players.size());
        currentGameSession = new GameSession(players, cardDeck.getAllCards());
        for (int i = 0; i < players.size(); i++) {
            players.get(i).getHand().addAll(initialHands.get(i));
        }
        currentGameSession.setCurrentPlayerIndex(0);
    }

    private void endGame(Player winner) {
        System.out.println(winner.getName() + " has won the game!");

        // Calculate and update scores for all players
        calculateAndUpdateScores(winner);

        // Save updated user data
        UserStorage.saveUserData(players);

        // Optionally, display the winner's information
        System.out.println("Scores updated. " + winner.getName() + " has won the game.");
    }

    private void calculateAndUpdateScores(Player winner) {
        int score = 0;
        for (Player player : players) {
            if (player != winner) {
                for (Card card : player.getHand()) {
                    score += card.getValue();
                }
                player.updateScore(-score);  // Deduct points based on remaining cards.
            }
        }
        winner.updateScore(score);  // Winner gains points based on cards left in other players' hands.
    }

    public void playCard(HumanPlayer player, Card card) {
        if (ruleEngine.isValidMove(card, currentGameSession.getTopCard(), currentGameSession.getCurrentColour())) {
            currentGameSession.addCardToDiscardPile(card);
            player.removeCardFromHand(card);
            ruleEngine.applyCardEffect(card, currentGameSession);
            if (player.getHand().isEmpty()) {
                endGame(player);
            } else {
                currentGameSession.advancePlayTurn();
            }
        } else {
            System.out.println("Invalid move: The card cannot be played.");
        }
    }
}
