package gui;

import players.HumanPlayer;
import players.Player;
import storage.UserStorage;
import utils.FileHandler;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class LoginWindow extends JFrame {

    private final JPanel mainPanel;
    private JTextField usernameTextField;
    private JPasswordField passwordField;
    private List<Player> players;
    private Map<String, String> passwords;

    public LoginWindow() {
        setTitle("Login");
        setSize(360, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        mainPanel = new JPanel();
        mainPanel.setLayout(null);
        getContentPane().add(mainPanel);
        initComponents();
        setVisible(true);
        loadUserData();
    }

    private void loadUserData() {
        players = UserStorage.loadUserData();
        passwords = UserStorage.loadPasswords();
    }

    private void initComponents() {
        addBackground();
        addUsernameField();
        addPasswordField();
        addLoginButton();
        addRegisterButton();
    }

    private void addBackground() {
        try {
            ImageIcon icon = new ImageIcon("C:\\Users\\ismay\\Downloads\\UnoProject\\UnoProject\\src\\gui\\images\\uno-logo.png");
            Image image = icon.getImage();
            Image newimg = image.getScaledInstance(245, 120, java.awt.Image.SCALE_SMOOTH);
            icon = new ImageIcon(newimg);
            JLabel background = new JLabel(icon);
            background.setBounds(60, 20, 240, 120);
            background.setOpaque(true);
            mainPanel.add(background);
        } catch (Exception e) {
            System.err.println("Error loading or scaling the background image: " + e.getMessage());
        }
    }

    private void addUsernameField() {
        usernameTextField = new JTextField();
        usernameTextField.setBounds(30, 180, 300, 40);
        usernameTextField.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
        usernameTextField.setHorizontalAlignment(JTextField.CENTER);
        mainPanel.add(usernameTextField);
    }

    private void addPasswordField() {
        passwordField = new JPasswordField();
        passwordField.setBounds(30, 240, 300, 40);
        passwordField.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
        passwordField.setHorizontalAlignment(JTextField.CENTER);
        mainPanel.add(passwordField);
    }

    private void addLoginButton() {
        JButton loginButton = new JButton("Login");
        loginButton.setBounds(100, 300, 160, 40);
        loginButton.addActionListener(e -> performLogin());
        mainPanel.add(loginButton);
    }

    private void addRegisterButton() {
        JButton registerButton = new JButton("Register");
        registerButton.setBounds(100, 360, 160, 40);
        registerButton.addActionListener(e -> performRegistration());
        mainPanel.add(registerButton);
    }

    private void performLogin() {
        String username = usernameTextField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter both username and password.", "Warning", JOptionPane.WARNING_MESSAGE);
        } else if (passwords.containsKey(username) && passwords.get(username).equals(password)) {
            System.out.println("Login successful for Username: " + username);
            new MainMenu(username);
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Invalid username or password.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void performRegistration() {
        String username = usernameTextField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter both username and password.", "Warning", JOptionPane.WARNING_MESSAGE);
        } else if (passwords.containsKey(username)) {
            JOptionPane.showMessageDialog(this, "Username already taken. Please choose a different username.", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            passwords.put(username, password);
            Player newPlayer = new HumanPlayer(username);
            players.add(newPlayer);
            UserStorage.saveUserData(players);
            UserStorage.savePasswords(passwords);
            JOptionPane.showMessageDialog(this, "Registration successful! Please log in.", "Success", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(LoginWindow::new);
    }
}
