package gui;

import game.GameManager;
import game.GameSession;
import players.Player;
import players.HumanPlayer;
import players.ComputerPlayer;
import cards.Card;
import cards.ActionCard;
import cards.NumberCard;
import cards.BasicWildCard;
import cards.SpecialWildCard;
import storage.GameStorage;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;

public class GameWindow extends JFrame {
    private GameManager gameManager;
    private JLabel sessionNameLabel;
    private JPanel playerHandPanel;
    private JPanel playerHandContainer;
    private JScrollPane playerHandScrollPane;
    private JPanel otherPlayersPanel;
    private JLabel drawPileLabel;
    private JLabel discardPileLabel;
    private JLabel directionLabel;
    private JButton declareUnoButton;
    private JButton startGameButton;
    private JButton drawCardButton;
    private JButton saveGameButton;
    private JButton nextCardButton;
    private JButton prevCardButton;
    private GameSession gameSession;
    private String sessionName;
    private boolean unoDeclared;
    private int cardIndex = 0;
    private List<Card> playerHand;

    private static final String IMAGE_DIRECTORY = "C:\\Users\\ismay\\Downloads\\UnoProject\\UnoProject\\src\\gui\\images\\";
    private static final int CARD_WIDTH = 80;
    private static final int CARD_HEIGHT = 120;

    public GameWindow(String sessionName, GameManager gameManager) {
        this.sessionName = sessionName;
        this.gameManager = gameManager;
        this.unoDeclared = false;
        setTitle("Game Session: " + sessionName);
        setSize(1080, 720);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        initComponents(sessionName);
        setVisible(true);
    }

    private void initComponents(String sessionName) {
        JPanel mainPanel = new JPanel(new BorderLayout());
        getContentPane().add(mainPanel);

        sessionNameLabel = new JLabel("Session: " + sessionName);
        sessionNameLabel.setHorizontalAlignment(SwingConstants.CENTER);
        sessionNameLabel.setFont(new Font("Arial", Font.BOLD, 24));
        mainPanel.add(sessionNameLabel, BorderLayout.NORTH);

        playerHandContainer = new JPanel(new BorderLayout());
        playerHandContainer.setBorder(BorderFactory.createTitledBorder("Your Hand"));
        mainPanel.add(playerHandContainer, BorderLayout.SOUTH);

        playerHandPanel = new JPanel();
        playerHandPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        playerHandScrollPane = new JScrollPane(playerHandPanel);
        playerHandScrollPane.setPreferredSize(new Dimension(900, 150)); // Adjust the height to make it shorter
        playerHandContainer.add(playerHandScrollPane, BorderLayout.CENTER);

        prevCardButton = new JButton("<");
        prevCardButton.addActionListener(this::prevCard);
        playerHandContainer.add(prevCardButton, BorderLayout.WEST);

        nextCardButton = new JButton(">");
        nextCardButton.addActionListener(this::nextCard);
        playerHandContainer.add(nextCardButton, BorderLayout.EAST);

        otherPlayersPanel = new JPanel(new GridLayout(0, 1));
        otherPlayersPanel.setBorder(BorderFactory.createTitledBorder("Other Players"));
        mainPanel.add(otherPlayersPanel, BorderLayout.WEST);

        JPanel centerPanel = new JPanel(new BorderLayout());

        drawPileLabel = new JLabel("Draw Pile: ");
        centerPanel.add(drawPileLabel, BorderLayout.WEST);

        discardPileLabel = new JLabel("Discard Pile: ");
        centerPanel.add(discardPileLabel, BorderLayout.EAST);

        directionLabel = new JLabel("Direction: ");
        centerPanel.add(directionLabel, BorderLayout.NORTH);

        mainPanel.add(centerPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        declareUnoButton = new JButton("Declare Uno");
        declareUnoButton.addActionListener(this::declareUno);
        declareUnoButton.setVisible(false); // Initially not visible
        buttonPanel.add(declareUnoButton);

        drawCardButton = new JButton("Draw Card");
        drawCardButton.addActionListener(this::drawCard);
        buttonPanel.add(drawCardButton);

        startGameButton = new JButton("Start Game");
        startGameButton.addActionListener(this::startGame);
        buttonPanel.add(startGameButton);

        saveGameButton = new JButton("Save Game");
        saveGameButton.addActionListener(this::saveGame);
        buttonPanel.add(saveGameButton);

        mainPanel.add(buttonPanel, BorderLayout.EAST);

        updateGameState();
    }

    private void updateGameState() {
        gameSession = gameManager.getCurrentGameSession();

        // Update draw pile label
        drawPileLabel.setText("Draw Pile: " + gameSession.getDrawPile().size() + " cards");

        // Update discard pile label
        Card topCard = gameSession.getTopCard();
        if (topCard != null) {
            discardPileLabel.setText("Discard Pile: ");
            discardPileLabel.setIcon(new ImageIcon(getScaledImage(getCardImagePath(topCard), CARD_WIDTH, CARD_HEIGHT)));
        }

        // Update direction label
        directionLabel.setText("Direction: " + gameSession.getGameDirection());

        // Update player hand panel
        Player currentPlayer = gameManager.getPlayers().get(gameSession.getCurrentPlayerIndex());
        if (currentPlayer instanceof HumanPlayer) {
            playerHand = currentPlayer.getHand();
            displayCurrentCards();

            // Show declareUnoButton if the player has only one card
            if (currentPlayer.getHand().size() == 1) {
                declareUnoButton.setVisible(true);
                unoDeclared = false; // Reset unoDeclared flag
            } else {
                declareUnoButton.setVisible(false);
            }
        }

        // Update other players panel
        otherPlayersPanel.removeAll();
        for (Player player : gameManager.getPlayers()) {
            if (player != currentPlayer) {
                JLabel playerLabel = new JLabel(player.getName() + " - " + player.getHandSize() + " cards");
                otherPlayersPanel.add(playerLabel);
            }
        }
        otherPlayersPanel.revalidate();
        otherPlayersPanel.repaint();
    }

    private void displayCurrentCards() {
        playerHandPanel.removeAll();
        if (!playerHand.isEmpty()) {
            int endIndex = Math.min(cardIndex + 5, playerHand.size());
            for (int i = cardIndex; i < endIndex; i++) {
                Card currentCard = playerHand.get(i);
                JButton cardButton = new JButton(new ImageIcon(getScaledImage(getCardImagePath(currentCard), CARD_WIDTH, CARD_HEIGHT)));
                cardButton.addActionListener(e -> playCard(currentCard));
                playerHandPanel.add(cardButton);
            }
        }
        playerHandPanel.revalidate();
        playerHandPanel.repaint();
    }

    private void playCard(Card card) {
        gameManager.playCard((HumanPlayer) gameManager.getPlayers().get(gameSession.getCurrentPlayerIndex()), card);
        if (!unoDeclared && declareUnoButton.isVisible()) {
            // Penalize for not declaring Uno
            for (int i = 0; i < 2; i++) {
                ((HumanPlayer) gameManager.getPlayers().get(gameSession.getCurrentPlayerIndex())).addCardToHand(gameSession.drawCard());
            }
            JOptionPane.showMessageDialog(this, "You didn't declare Uno! Draw 2 cards as penalty.", "Penalty", JOptionPane.WARNING_MESSAGE);
            gameManager.getCurrentGameSession().advancePlayTurn();
        }
        updateGameState();
        processNextTurn();
    }

    private void drawCard(ActionEvent e) {
        HumanPlayer currentPlayer = (HumanPlayer) gameManager.getPlayers().get(gameSession.getCurrentPlayerIndex());
        currentPlayer.addCardToHand(gameSession.drawCard());
        updateGameState();
        processNextTurn();
    }

    private void processNextTurn() {
        gameManager.getCurrentGameSession().advancePlayTurn();
        Player nextPlayer = gameManager.getPlayers().get(gameSession.getCurrentPlayerIndex());
        if (nextPlayer instanceof ComputerPlayer) {
            gameManager.processTurn();
            updateGameState();
            processNextTurn();
        } else {
            updateGameState();
        }
    }

    private void declareUno(ActionEvent e) {
        declareUnoButton.setVisible(false);
        unoDeclared = true; // Set unoDeclared flag
        JOptionPane.showMessageDialog(this, "Uno declared!");
    }

    private void startGame(ActionEvent e) {
        gameManager.startNewGame();
        updateGameState();
    }

    private void saveGame(ActionEvent e) {
        GameStorage.saveGameSession(gameSession, sessionName);
        JOptionPane.showMessageDialog(this, "Game saved successfully!", "Save Game", JOptionPane.INFORMATION_MESSAGE);
    }

    private void nextCard(ActionEvent e) {
        if (playerHand != null && !playerHand.isEmpty()) {
            cardIndex = Math.min(cardIndex + 1, playerHand.size() - 1);
            displayCurrentCards();
        }
    }

    private void prevCard(ActionEvent e) {
        if (playerHand != null && !playerHand.isEmpty()) {
            cardIndex = Math.max(cardIndex - 1, 0);
            displayCurrentCards();
        }
    }

    private String getCardImagePath(Card card) {
        String fileName;
        if (card instanceof NumberCard) {
            fileName = card.getColor().name().toLowerCase() + "-" + ((NumberCard) card).getNumber() + ".png";
        } else if (card instanceof ActionCard) {
            fileName = card.getColor().name().toLowerCase() + "-" + ((ActionCard) card).getActionType().name().toLowerCase() + ".png";
        } else if (card instanceof BasicWildCard) {
            fileName = "wild-basic.png";
        } else if (card instanceof SpecialWildCard) {
            fileName = "wild-special.png";
        } else {
            fileName = "wild-basic.png";
        }
        return IMAGE_DIRECTORY + fileName;
    }

    private Image getScaledImage(String imagePath, int width, int height) {
        ImageIcon icon = new ImageIcon(imagePath);
        return icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
    }

    public static void main(String[] args) {
        // Example usage with dummy data
        List<Player> players = List.of(new HumanPlayer("testUser"), new ComputerPlayer("Bot1"), new ComputerPlayer("Bot2"));
        SwingUtilities.invokeLater(() -> new GameWindow("Session1", new GameManager(players)));
    }
}
