package gui;

import game.GameManager;
import game.GameSession;
import players.HumanPlayer;
import players.Player;
import players.ComputerPlayer;
import storage.UserStorage;
import storage.GameStorage;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import utils.FileHandler;

public class MainMenu extends JFrame {
    private JButton continueGameButton;
    private JButton newGameButton;
    private JPanel mainPanel;
    private String username;
    private JTable leaderboardTable;

    public MainMenu(String username) {
        this.username = username;
        setTitle("UNO Main Menu");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        initComponents();
        setVisible(true);
    }

    private void initComponents() {
        mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());

        continueGameButton = new JButton("Continue Game");
        continueGameButton.addActionListener(this::continueGame);
        newGameButton = new JButton("New Game");
        newGameButton.addActionListener(this::newGame);

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(newGameButton);
        buttonPanel.add(continueGameButton);

        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        // Leaderboard
        JPanel leaderboardPanel = new JPanel(new BorderLayout());
        leaderboardPanel.setBorder(BorderFactory.createTitledBorder("Leaderboard"));

        leaderboardTable = new JTable();
        JScrollPane scrollPane = new JScrollPane(leaderboardTable);
        leaderboardPanel.add(scrollPane, BorderLayout.CENTER);

        mainPanel.add(leaderboardPanel, BorderLayout.CENTER);

        populateLeaderboardTable();

        add(mainPanel);
    }

    private void populateLeaderboardTable() {
        List<Player> players = UserStorage.loadUserData();
        String[] columnNames = {"Username", "Total Score"};
        String[][] data = new String[players.size()][2];

        for (int i = 0; i < players.size(); i++) {
            Player player = players.get(i);
            data[i][0] = player.getName();
            data[i][1] = String.valueOf(player.getTotalScore());
        }

        leaderboardTable.setModel(new javax.swing.table.DefaultTableModel(data, columnNames));
    }

    private void newGame(ActionEvent e) {
        String sessionName = JOptionPane.showInputDialog(this, "Enter session name:");
        if (sessionName == null || sessionName.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Session name cannot be empty.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String[] playerNumbers = {"2", "3", "4", "5", "6", "7", "8", "9", "10"};
        String selectedPlayerNumber = (String) JOptionPane.showInputDialog(this, "Select number of players:", "New Game",
                JOptionPane.QUESTION_MESSAGE, null, playerNumbers, playerNumbers[0]);

        if (selectedPlayerNumber == null) {
            return;
        }

        int numberOfPlayers = Integer.parseInt(selectedPlayerNumber);
        List<Player> players = new ArrayList<>();
        players.add(new HumanPlayer(username));
        for (int i = 1; i < numberOfPlayers; i++) {
            players.add(new ComputerPlayer("Bot" + i));
        }

        GameManager gameManager = new GameManager(players);
        SwingUtilities.invokeLater(() -> new GameWindow(sessionName, gameManager));
        dispose();
    }

    private void continueGame(ActionEvent e) {
        List<String> sessionNames;
        try {
            sessionNames = FileHandler.readFile("C:\\Users\\ismay\\Downloads\\UnoProject\\UnoProject\\src\\session_names.txt");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error reading saved game sessions.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String[] options = sessionNames.toArray(new String[0]);
        String selectedSession = (String) JOptionPane.showInputDialog(
                this,
                "Select a saved game session:",
                "Continue Game",
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]
        );

        if (selectedSession != null) {
            GameSession gameSession = GameStorage.loadGameSession(selectedSession);
            if (gameSession != null) {
                List<Player> players = gameSession.getPlayers();
                GameManager gameManager = new GameManager(players);
                gameManager.setCurrentGameSession(gameSession);
                SwingUtilities.invokeLater(() -> new GameWindow(selectedSession, gameManager));
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to load the selected game session.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainMenu("testUser"));
    }
}
